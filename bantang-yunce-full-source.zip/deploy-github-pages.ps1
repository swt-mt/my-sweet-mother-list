param(
  [string]$Owner = "swt-mt",
  [string]$Repo = "my-sweet-mother-list",
  [string]$Branch = "main",
  [switch]$ConfigurePages
)

$ErrorActionPreference = "Stop"

$token = $env:GH_TOKEN
if (-not $token) {
  $token = $env:GITHUB_TOKEN
}

if (-not $token) {
  throw "Please set GH_TOKEN or GITHUB_TOKEN before running this script. Do not paste the token into chat."
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$files = @(
  @{ Local = Join-Path $root "index.html"; Remote = "index.html" },
  @{ Local = Join-Path $root "pregnancy-mama-checklist.html"; Remote = "pregnancy-mama-checklist.html" }
)

$headers = @{
  Authorization = "Bearer $token"
  Accept = "application/vnd.github+json"
  "X-GitHub-Api-Version" = "2022-11-28"
  "User-Agent" = "bantang-yunce-deploy"
}

function Invoke-GitHubJson {
  param(
    [string]$Method,
    [string]$Uri,
    $Body = $null
  )

  if ($null -eq $Body) {
    return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $headers
  }

  return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $headers -ContentType "application/json" -Body ($Body | ConvertTo-Json -Depth 10)
}

foreach ($file in $files) {
  if (-not (Test-Path $file.Local)) {
    throw "Missing local file: $($file.Local)"
  }

  $remotePath = $file.Remote
  $contentUri = "https://api.github.com/repos/$Owner/$Repo/contents/$remotePath"
  $sha = $null

  try {
    $existing = Invoke-GitHubJson -Method GET -Uri "$($contentUri)?ref=$Branch"
    $sha = $existing.sha
  } catch {
    if ($_.Exception.Response.StatusCode.value__ -ne 404) {
      throw
    }
  }

  $bytes = [System.IO.File]::ReadAllBytes($file.Local)
  $body = @{
    message = "Publish Bantang Yunce static site"
    content = [Convert]::ToBase64String($bytes)
    branch = $Branch
  }

  if ($sha) {
    $body.sha = $sha
  }

  Invoke-GitHubJson -Method PUT -Uri $contentUri -Body $body | Out-Null
  Write-Host "Uploaded $remotePath"
}

if ($ConfigurePages) {
  $pagesUri = "https://api.github.com/repos/$Owner/$Repo/pages"
  $pagesBody = @{
    source = @{
      branch = $Branch
      path = "/"
    }
  }

  try {
    Invoke-GitHubJson -Method GET -Uri $pagesUri | Out-Null
    Invoke-GitHubJson -Method PUT -Uri $pagesUri -Body $pagesBody | Out-Null
    Write-Host "Updated GitHub Pages settings"
  } catch {
    if ($_.Exception.Response.StatusCode.value__ -eq 404) {
      Invoke-GitHubJson -Method POST -Uri $pagesUri -Body $pagesBody | Out-Null
      Write-Host "Enabled GitHub Pages"
    } else {
      throw
    }
  }

  Write-Host ""
  Write-Host "Done. Public URL:"
  Write-Host "https://$Owner.github.io/$Repo/"
} else {
  Write-Host ""
  Write-Host "Uploaded files successfully."
  Write-Host "Now enable GitHub Pages once in the repository UI:"
  Write-Host "Settings > Pages > Build and deployment > Source > Deploy from a branch"
  Write-Host "Branch: $Branch / Folder: (root)"
  Write-Host "Then visit:"
  Write-Host "https://$Owner.github.io/$Repo/"
}
